#include<stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
     int num = atoi(argv[1]);
     printf("Child:Even series:");
     for(int i= 0; i < num; i++){
     	if(i%2 == 0){
     	    printf("%d ",i);
     	}
     }
     printf("\n");
}

