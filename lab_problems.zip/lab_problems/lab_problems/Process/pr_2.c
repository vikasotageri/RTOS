/*2.Let the parent fork and let the child execute ls command. Observe the result with and without having wait()  system call in the parent.*/ 


#include <stdlib.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>
#include <stdint.h>

int main(){
    pid_t pid;int status;
    pid = fork();
    if(pid < 0){
       printf("Child Not Created\n");
       exit(0);
    }
    else if(pid == 0){
    //sleep(10);
       execl("/bin/ls","ls","-lh",".",NULL);
       exit(0);
    }
       //sleep(10);
       wait(&status);
       printf("Parent: I am done, child returned successfully\n");

    
    

}
