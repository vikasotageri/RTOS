/*4.Create a child through fork(). Let the child generate the fibonacci series (1, 1, 2, 3, 5, 8…) upto n numbers. The value of n has to passed as a command line argument.*/

#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
#include<stdlib.h>
#include<stdio.h>

void fib(int num){
    int a = 0;
    int b = 1;
    printf("Fib series: %d %d ",a,b);
    for(int i = 2; i < num; i++){
       int c = a+b;
       a = b;
       b = c;
       printf("%d ",c);
       
    }
}
int main(int argc, char *argv[]){
     if(argc < 2){
         printf("Insufficient arguments:\n");
         exit(0);
     }
     pid_t pid; int status;
     int num = atoi(argv[1]);
     
     pid = fork();
     if(pid < 0){
        printf("child not created");
        exit(0);
     }
     else if (pid == 0){
        fib(num);
     }
     else{
     
     	wait(&status);
     	printf("Successfully completed\n");
     }
} 
