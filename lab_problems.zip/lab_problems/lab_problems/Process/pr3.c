/*3.	Let the parent create 4 children. Make them execute ls, ls –l, pwd and  date commands. (One child executes one command.)*/

#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
#include<stdlib.h>
#include<stdio.h>

int main(){
	pid_t pid;
	int status;
	if((pid = fork()) == 0){
	    execl("/bin/ls","ls",".",NULL);
	}
	wait(&status);
	if((pid = fork()) == 0){
	    execl("/bin/ls","ls","-l",".",NULL);
	} 
	wait(&status);
	if((pid = fork()) == 0){
	    execl("/bin/pwd","pwd",NULL);
	}
	wait(&status);
	if((pid = fork()) == 0){
	    execl("/bin/date","date",NULL);
	}
	wait(&status);
	printf("Parent: I am done, Child returned successfully\n");
	
	
	

}
