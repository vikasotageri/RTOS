/*7.	Let the parent create 2 children which work on a common sample file. Let one child count the total number of lines  in the file while the other counts the total number of characters  in the same file. Provide the filename as a command line argument. */


#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/types.h>
int main(int argc,char *argv[]){
	pid_t child1,child2;
    int status;
	child1 = fork();
    if(child1 < 0){
    	printf("child1 Not Created\n");
    	exit(0);
    }
    if(child1 == 0){
    	printf("Number of lines:");
    	execl("/bin/wc","wc","-l",argv[1],NULL);
    }
    wait(&status);
    printf("\n");
    child2 = fork();
    if(child2 < 0){
    	printf("child2 Not Created\n");
    	exit(0);
    }

    if(child2 == 0){
    	printf("Number of character:");
    	execl("/bin/wc","wc","-c",argv[1],NULL);
    }
    wait(&status);
    printf("\nParent: child execution successfully\n");


}