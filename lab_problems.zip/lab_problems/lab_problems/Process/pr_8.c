/*8.	Let the parent create 2 children which work on a common sample file. Let one child convert all lowercase to uppercase  in the file while the other counts the total number of character ‘a’ s in the same file. Provide the filename as a command line argument*/


#include <stdio.h>
#include <ctype.h>   // for toupper()
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>


void low_to_high(const char *filename) {
    FILE *fp = fopen(filename, "r+");  // open for reading + writing
    if (fp == NULL) {
        printf("Error opening file: %s\n", filename);
        return;
    }

    int ch;
    long pos;

    while ((ch = fgetc(fp)) != EOF) {
        if (ch >= 'a' && ch <= 'z') {     // check if lowercase
            pos = ftell(fp);              // get current position
            fseek(fp, pos - 1, SEEK_SET); // move back one char
            fputc(toupper(ch), fp);       // overwrite with uppercase
            fseek(fp, pos, SEEK_SET);     // move forward again
        }
    }

    fclose(fp);
}


void countCharInFile(const char *filename, char target) {
    FILE *fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Error opening file: %s\n", filename);
        exit(0); // error code
    }

    int count = 0;
    int ch;

    while ((ch = fgetc(fp)) != EOF) {
        if (ch == target) {
            count++;
        }
    }

    fclose(fp);
    printf("Number of times %c occurs in %s is %d\n",target,filename,count);
}
int main(int argc, char *argv[]) {
    pid_t pid;
    int status;
    
    pid = fork();
    if(pid < 0){
       printf("child not created\n");
       exit(0);
    }
    else if(pid == 0){
            low_to_high(argv[1]);
            exit(0);
    }
    wait(&status);
    
    pid = fork();
    if(pid < 0){
        printf("Not created child\n");
        exit(0);
    }
    else if(pid == 0){
        countCharInFile(argv[1],'A');
        exit(0);
    }
    wait(&status);
    printf("Parent: Successfully child returned\n");
    

    return 0;
}


