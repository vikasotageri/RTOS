/*5.	Let the parent create a child using fork(). Let the parent geneate an odd series upto n numbers  (1, 3, 5, 7, 9…) and let the child create an even series upto n numbers (0, 2, 4, 6, 8 …). (i) Pass the value of n as a command line argument. (ii) Read the value of n from the user.*/

#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
#include<stdlib.h>
#include<stdio.h>


void even(int num){
     printf("Child:Even series:");
     for(int i= 0; i < num; i++){
     	if(i%2 == 0){
     	    printf("%d ",i);
     	}
     }
     printf("\n");
}

void odd(int num){
     printf("Parent:ODD series:");
     for(int i= 0; i < num; i++){
     	if(i%2 != 0){
     	    printf("%d ",i);
     	}
     }
     printf("\n");
}

int main(int argc, char *argv[]){
    if(argc < 2){
    	printf("Insufficient arguments\n");
    	exit(0);
    }
    pid_t pid; int status;
    int num = atoi(argv[1]);
    odd(num);
    pid = fork();
    if(pid < 0){
        printf("child not created");
        exit(0);
     }
     
     else if (pid == 0){
        even(num);
     }
     else{
     
     	wait(&status);
     	//odd(num);
     	printf("Successfully completed\n");
     }
}
