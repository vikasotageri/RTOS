


/*1.Demonstrate fork() system call. Let the parent process display its pid, ppid and a message ‘I’m the parent’. Also let the child display its pid, ppid and a message ‘I’m the child’.*/


#include <stdlib.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>
#include <stdint.h>

int main(){
    int pid,status;
    printf("I am parent, ppid = %d,pid = %d\n", getppid(), getpid());
    pid = fork();
    if(pid < 0){
    	printf("Child not created");
    
    }
    if(pid == 0){
    	printf("I am child, ppid = %d,pid = %d\n",getppid(),getpid());
    	exit(0);
    }

    wait(&status);
    printf("msg from parent, i am done\n");
}
