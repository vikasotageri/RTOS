/*
5.	Let the parent create a child using fork(). Let the parent geneate an odd series upto n numbers  (1, 3, 5, 7, 9…) and let the child create an even series upto n numbers (0, 2, 4, 6, 8 …). (i) Pass the value of n as a command line argument. (ii) Read the value of n from the user.
6.	Achieve the same as in Q(5) by using exec() system calls. 

*/

/*5.	Let the parent create a child using fork(). Let the parent geneate an odd series upto n numbers  (1, 3, 5, 7, 9…) and let the child create an even series upto n numbers (0, 2, 4, 6, 8 …). (i) Pass the value of n as a command line argument. (ii) Read the value of n from the user.*/

#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
#include<stdlib.h>
#include<stdio.h>





int main(int argc, char *argv[]){
    if(argc < 2){
    	printf("Insufficient arguments\n");
    	exit(0);
    }
    pid_t pid; int status;
    pid = fork();
    if(pid < 0){
        printf("child not created");
        exit(0);
     }
     
     else if (pid == 0){
        execl("./even","even",argv[1],NULL);
     }
     else{
     
     	wait(&status);
     	execl("./odd","odd",argv[1],NULL);
     	printf("Successfully completed\n");
     }
}
