#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<ctype.h>
#include <stdlib.h>

int main(){
   pid_t pid;
   int status;
   pid = fork();
   if(pid == 0){
      execlp("ls","ls","-lh",NULL);
      exit(EXIT_FAILURE);
   }
   wait(&status);
   printf("Status optained successfully\n");
   return 0;
   
}
