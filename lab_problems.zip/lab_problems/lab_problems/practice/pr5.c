//*5.	Let the parent create a child using fork(). Let the parent geneate an odd series upto n numbers  (1, 3, 5, 7, 9…) and let the child create an even series upto n numbers (0, 2, 4, 6, 8 …). (i) Pass the value of n as a command line argument. (ii) Read the value of n from the user.

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>

void odd(int n){
printf("odd:");
   for(int i = 0; i <= n; i++){
       if(i%2!=0){
           printf("%d ",i);
       }
   }
   printf("\n");
}

void even(int m){
   printf("even:");
   for(int i = 0; i <= m; i++){
       if(i%2==0){
           printf("%d ",i);
       }
   }
   printf("\n");
}

int main(int argc, char *argv[]){
   if(argc < 2){
      perror("Insufficient arguments\n");
      exit(EXIT_FAILURE);
   }
   pid_t pid;
   int status;
   int arg = atoi(argv[1]);
   pid = fork();
   if(pid < 0){
      perror("process creation failed\n");
      exit(EXIT_FAILURE);
   }
   else if( pid == 0){
      even(arg);
      exit(EXIT_SUCCESS);
   }
   else{
     wait(&status);
     odd(arg);
     printf("executed successfully\n");
   }
}
