/*8.*	Let the parent create 2 children which work on a common sample file. Let one child convert all lowercase to uppercase  in the file while the other counts the total number of character ‘a’ s in the same file. Provide the filename as a command line argument.*/
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
#include<ctype.h>
#include<stdio.h>

//#define FILE_NAME "sample.txt"
int main(int argc,char *argv[]){
    pid_t pid;
    int status;
    pid = fork();
    if ( pid < 0){
       perror("FAILED\n");
       exit(EXIT_FAILURE);
    }
    else if(pid == 0){
        FILE *fp = fopen(argv[1],"r");
        if(fp == NULL){
           perror("Error in opening\n");
           exit(EXIT_FAILURE);
        }
        char ch;
        int cnt = 0;
        while((ch = getc(fp))!=EOF){
           if(ch == 'a'){
              cnt++;
           }
        }
        printf("Number of 'a' in file = %d\n",cnt);
        fclose(fp);
        exit(EXIT_SUCCESS);
    }
    wait(&status);
    
    pid = fork();
    if(pid == 0){
        FILE *fp = fopen(argv[1],"r+");
        if(fp == NULL){
           perror("Error in opening\n");
           exit(EXIT_FAILURE);
        }
        char ch;
        while((ch = fgetc(fp))!=EOF){
            if(islower(ch)){
                fseek(fp,-1,SEEK_CUR);
                putc(toupper(ch),fp);
            }
        }
        fclose(fp);
        exit(EXIT_SUCCESS);
    }
    wait(&status);
    printf("child returned successfully\n");
    return 0;
}
