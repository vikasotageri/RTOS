/**Create a common shared memory area where in one thread writes a string termed “Hello There”; the second thread reads the string and displays it on the screen. Also the second string converts all lower case to upper case and vice versa in the shared memory. Next the first thread will read this from the shared memory and will output the same to the screen. */

#include<pthread.h>
#include<unistd.h>
#include<stdlib.h>
#include <ctype.h>
#include<stdio.h>
#include<string.h>
pthread_mutex_t lock;
int flag = 0;
char *str;
void *thread1(void *arg){
      pthread_mutex_lock(&lock);
      if(flag == 0){
         str = (char *)malloc(sizeof(char)*20);
         strcpy(str,"Hello There\n");
         flag = 1;
      }
      pthread_mutex_unlock(&lock);
      while(1){
         pthread_mutex_lock(&lock);
         if(flag == 2){
            printf("%s",str);
            pthread_mutex_unlock(&lock);
            break;
         }
         pthread_mutex_unlock(&lock);       
      }
      pthread_exit(NULL);   
}

void *thread2(void *arg){
    while(1){
        
           pthread_mutex_lock(&lock);
           if(flag == 1){
           printf("%s",str);
           int j =0;
           for(int i = 0; str[i]!='\0';i++){
               if(islower(str[i])){
                   str[j++] = toupper(str[i]);
               }
               else{
                  str[j++] = tolower(str[i]);
               }
           }
           flag = 2;
           pthread_mutex_unlock(&lock);
           break;
        }
        pthread_mutex_unlock(&lock);
    }
    pthread_exit(NULL);
}

int main(){
   pthread_t tid1,tid2;
   if(pthread_create(&tid1,NULL,thread1,NULL)){
      perror("thread creation failed");
      exit(1);
   }
   if(pthread_create(&tid2,NULL,thread2,NULL)){
      perror("thread creation failed");
      exit(1);      
   }
   
   pthread_join(tid1,NULL);
   pthread_join(tid2,NULL);
   return 0;
}
