/**create and save a  sample text (a file containing any text) in your current working directory . Next write a program which creates two threads such that one thread counts the total number of words present  in the file and the other thread changes all upper case characters to lower case.*/

#include<stdio.h>
#include<unistd.h>
#include<ctype.h>
#include<string.h>
#include<pthread.h>

#define FILE_NAME  "sample.txt"
pthread_mutex_t  lock;
int flag = 0;
void *thread1(void *arg){
   pthread_mutex_lock(&lock);
   FILE *fp = fopen(FILE_NAME,"r");
   if(fp == NULL){
      perror("FILE open failed\n");
      pthread_exit(NULL);
   }
   int cnt = 0;
   int in_word =0;
   char ch;
   while((ch = fgetc(fp)) != EOF){
      if(ch == ' '){
         cnt++;
         in_word = 0;
      }
      else{
         in_word++;
      }
   }
   if(in_word) cnt++;
   fclose(fp);
   printf("Number of word = %d\n",cnt);
   flag = 1;
   pthread_mutex_unlock(&lock);
   pthread_exit(NULL);
}

void *thread2(void *arg){
   while(1){
       pthread_mutex_lock(&lock);
       if(flag == 1){
          FILE *fp = fopen(FILE_NAME,"r+");
          if(fp == NULL){
              perror("FILE open failed\n");
              pthread_exit(NULL);
          }
          char ch;
          while((ch = fgetc(fp)) != EOF){
              if(isupper(ch)){
                 fseek(fp,-1,SEEK_CUR);
                 putc(tolower(ch),fp);
              }
          }
          pthread_mutex_unlock(&lock);
          break;         
       }
       pthread_mutex_unlock(&lock);
       usleep(10000);
   }
   pthread_exit(NULL);
}

int main() {
    pthread_t tid1, tid2;

    pthread_mutex_init(&lock, NULL);

    pthread_create(&tid1, NULL, thread1, NULL);
    pthread_create(&tid2, NULL, thread2, NULL);

    pthread_join(tid1, NULL);
    pthread_join(tid2, NULL);

    pthread_mutex_destroy(&lock);

    return 0;
}
