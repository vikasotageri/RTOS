/**Create two threads in a main program, let the first thread execute a function to display a message namely “this is thread one” , similarly let the second thread displays “this is thread two’*/

#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<pthread.h>
#include<stdlib.h>

void *fun(void *msg){
   char *m = (char*)msg;
   printf("%s",m);
   pthread_exit(NULL);
}
void *fun1(void *msg){
   char *m = (char*)msg;
   printf("%s",(char*)msg);
   pthread_exit(NULL); 
}

int main(){
   pthread_t tid1,tid2;
   char *msg1 = "this thread one\n";
   char *msg2 = "this is thread two\n";
   if(pthread_create(&tid1,NULL,fun,(void*)msg1)){
      perror("thread creation failed");
      exit(1);
   }
   if(pthread_create(&tid2,NULL,fun1,(void*)msg2)){
      perror("thread creation failed");
      exit(1);      
   }
   
   pthread_join(tid1,NULL);
   pthread_join(tid2,NULL);
   return 0;
}
