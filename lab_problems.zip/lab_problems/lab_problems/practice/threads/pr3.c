/**Next create a common shared memory area where in one thread writes a sequence of numbers, the second thread reads the numbers, calculates their  sum and displays the result to the screen.*/
#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<pthread.h>
#include<string.h>
#include<unistd.h>
pthread_mutex_t lock;
int *arr;
int flag = 0;
void *thread1(void *arg){
   pthread_mutex_lock(&lock);
   arr = (int *)malloc(sizeof(int)*10);
   for(int i = 0; i < 10; i++){
      printf("Enter the number:");
      scanf("%d",&arr[i]);
   }
   flag = 1;
   pthread_mutex_unlock(&lock);
   pthread_exit(NULL);
}
void *thread2(void *arg){
   while(1){ 
	   pthread_mutex_lock(&lock);
	   if(flag == 1){
		   int sum = 0;
		   for(int i = 0; i < 10; i++){
		      sum = sum + arr[i];
		   }
		   printf("sum of Numbers:%d\n",sum);
		   pthread_mutex_unlock(&lock);
		   break;
           }
           pthread_mutex_unlock(&lock);
           usleep(10000);
	   
   }
   pthread_exit(NULL);
}
int main() {
    pthread_t tid1, tid2;

    pthread_mutex_init(&lock, NULL);

    pthread_create(&tid1, NULL, thread1, NULL);
    pthread_create(&tid2, NULL, thread2, NULL);

    pthread_join(tid1, NULL);
    pthread_join(tid2, NULL);

    pthread_mutex_destroy(&lock);

    return 0;
}
