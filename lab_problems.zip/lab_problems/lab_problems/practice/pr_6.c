//*5.	Let the parent create a child using fork(). Let the parent geneate an odd series upto n numbers  (1, 3, 5, 7, 9…) and let the child create an even series upto n numbers (0, 2, 4, 6, 8 …). (i) Pass the value of n as a command line argument. (ii) Read the value of n from the user.
//*6.	Achieve the same as in Q(5) by using exec() system calls.


#include<stdlib.h>
#include<sys/wait.h>
#include<unistd.h>
#include<stdio.h>

int main(int argc, char *argv[]){
   if(argc < 2){
      printf("Insufficient args\n");
      exit(EXIT_FAILURE);
   }
   pid_t pid;
   int status;
   if((pid=fork()) < 0){
      perror("failed\n");
      exit(EXIT_FAILURE);
   }
   else if(pid == 0){
      execl("./even","even",argv[1],NULL);
      exit(EXIT_FAILURE);
   }
   wait(&status);
   execl("./odd","odd",argv[1],NULL);
   exit(EXIT_FAILURE);

}
