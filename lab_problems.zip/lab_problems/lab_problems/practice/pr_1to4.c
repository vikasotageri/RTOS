//*1.	Demonstrate fork() system call. Let the parent process display its pid, ppid and a message ‘I’m the parent’. Also let the child display its pid, ppid and a message ‘I’m the child’.
//*2.	Let the parent fork and let the child execute ls command. Observe the result with and without having wait()  system call in the parent.
//*3.	Let the parent create 4 children. Make them execute ls, ls –l, pwd and  date commands. (One child executes one command.)
//*4.	Create a child through fork(). Let the child generate the fibonacci series (1, 1, 2, 3, 5, 8…) upto n numbers. The value of n has to passed as a command line argument.


#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<ctype.h>
#include <stdlib.h>

void pr1(){
   pid_t pid;
   int status;
   printf("I am the parent.pid = %d,ppid=%d\n",getpid(),getppid());
   pid = fork();
   if(pid < 0){
      perror("process creation failed\n");
      exit(0);
   }
   if(pid == 0){
      printf("I am the child. pid = %d,ppid=%d\n",getpid(),getppid());
   }
   wait(&status);
   printf("child returned successfully\n");
}
void pr2(){
  pid_t pid;
  int status;
  pid = fork();
  if(pid < 0){
     perror("FAILED\n");
     exit(0);
  }
  else if(pid == 0){
     execl("/bin/ls","ls","-lh",".",NULL);
     perror("failed");
     exit(0);
  }
  wait(&status);
  printf("child executed sucessfully\n");
}
void pr3(){
   pid_t pid;
   int status;
   if((pid = fork()) == 0){
   printf("LS:\n");
      execl("/bin/ls","ls",NULL);
      perror("failed\n");
      exit(1);
   }
   wait(&status);
   if((pid = fork()) == 0){
   printf("LS -l:\n");
     execl("/bin/ls","ls","-l",NULL);
      perror("failed\n");
      exit(1);
   }
   wait(&status);
   if((pid = fork()) == 0){
     printf("PWD:\n");
     execl("/bin/pwd","pwd",NULL);
   }
   wait(&status);
   if((pid = fork()) == 0){
   printf("DATE:\n");
     execl("/bin/date","date",NULL);
   }
   wait(&status);
   printf("child executed successfully\n");
}
void fib(int n){
  int a = 0;
  int b = 1;
  printf("%d %d ",a,b);
  for(int i = 2; i < n;i++){
      int c = a + b;
      a = b;
      b = c;
      printf("%d ",c);
  }
  printf("\n");
}
int pr4(int arg){
   pid_t pid;
   int status;
   pid = fork();
   if( pid < 0){
      perror("error in creation\n");
      exit(0);
   }
   else if (pid == 0){
      fib(arg);
      exit(0);
   }
   else{
      wait(&status);
      printf("child executed successfully\n");
   }
}
int main(int argc,char *argv[]){
   int arg = atoi(argv[1]);
   if(argc < 2){
     printf("argument not passed\n");
     exit(1);
   }
   printf("arg = %d\n",arg);
   pr4(arg);

}
