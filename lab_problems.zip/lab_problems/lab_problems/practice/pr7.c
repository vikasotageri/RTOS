/*7.*	Let the parent create 2 children which work on a common sample file. Let one child count the total number of lines  in the file while the other counts the total number of characters  in the same file. Provide the filename as a command line argument.*/
#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<unistd.h>

int main(int argc, char *argv[]){
   pid_t pid;
   int status;
   if(argc < 2){
      printf("Insufficient arguments\n");
      exit(EXIT_FAILURE);
   }
   pid = fork();
   if(pid < 0){
     exit(EXIT_FAILURE);
   }
   else if( pid == 0){
       printf("Total NUmber of Lines:");
       fflush(stdout);
       execl("/bin/wc","wc","-l",argv[1],NULL);
       exit(EXIT_FAILURE);
   }
   wait(&status);
   pid = fork();
   if(pid < 0){
     exit(EXIT_FAILURE);
   }
   else if( pid == 0){
       printf("Total NUmber of Lines:");
       fflush(stdout);
       execl("/bin/wc","wc","-c",argv[1],NULL);
       exit(EXIT_FAILURE);
   }
   wait(&status);
   printf("Execution success\n");
   exit(EXIT_SUCCESS);
}
