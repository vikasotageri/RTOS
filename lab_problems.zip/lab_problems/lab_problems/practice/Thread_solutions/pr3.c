/**Next create a common shared memory area where in one thread writes a sequence of numbers, the second thread reads the numbers, calculates their  sum and displays the result to the screen.*/
#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>
#include<ctype.h>
#include<string.h>

pthread_mutex_t lock;
int flag = 0;
int arr[10];
void *thread1(void *arg){
      pthread_mutex_lock(&lock);
      for(int i = 0; i < 10; i++){
      	printf("enter the number:");
      	scanf("%d",&arr[i]);
      }
      pthread_mutex_unlock(&lock);
      pthread_exit(NULL);
}
void *thread2(void *arg){
	pthread_mutex_lock(&lock);
	int sum = 0;
	for(int i = 0; i < 10; i++){
		sum+=arr[i];
	}
	pthread_mutex_unlock(&lock);
	printf("Sum = %d\n",sum);
	pthread_exit(NULL);
}

int main(){
	pthread_t tid1,tid2;
	pthread_create(&tid1,NULL,thread1,NULL);
	pthread_create(&tid2,NULL,thread2,NULL);
	pthread_join(tid1,NULL);
	pthread_join(tid2,NULL);

	pthread_mutex_destroy(&lock);
}