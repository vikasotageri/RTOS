/**Create a common shared memory area where in one thread writes a string termed “Hello There”; the second thread reads the string and displays it on the screen. 
 * Also the second string converts all lower case to upper case and vice versa in the shared memory. 
 * Next the first thread will read this from the shared memory and will output the same to the screen. */

#include<pthread.h>
#include<ctype.h>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
pthread_mutex_t lock;
char *str;
int flag = 0;
void *thread1(void *arg){
     pthread_mutex_lock(&lock);
     str = (char *)malloc(20*sizeof(char));
     strcpy(str,"Hello There\n");
     flag = 1;
     pthread_mutex_unlock(&lock);
     while(1){
           pthread_mutex_lock(&lock);
           if(flag == 2){
            printf("%s",str);
            pthread_mutex_unlock(&lock);
            break;
           }
           pthread_mutex_unlock(&lock);
           usleep(1000);

     }
     pthread_exit(NULL);
}

void *thread2(void *arg){
   pthread_mutex_lock(&lock);
   if(flag == 1){
      printf("%s",str);
      for(int i = 0; i < strlen(str);i++){
         if(isupper(str[i])){
            str[i] = tolower(str[i]);
         }
         else{
            str[i] = toupper(str[i]);
         }
      }
   }
   flag = 2;
   pthread_mutex_unlock(&lock);
   pthread_exit(NULL);
    
}

int main(){
   pthread_t tid1,tid2;
   
   pthread_create(&tid1,NULL,thread1,NULL);
   pthread_create(&tid2,NULL,thread2,NULL);

   pthread_join(tid1,NULL);
   pthread_join(tid2,NULL);
}
