/**Declare a matrix of size m x n , and populate it. (Fill it) Create m threads such that each thread calculates the ith coloum sum.
 *Let the main thread  display each coloum sum result as well as the total sum.*/

#include<stdio.h>
#include<pthread.h>
#include<unistd.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>

#define M 2
#define N 3
int arr[M][N];
int cl_sum[N];

void *col_sum(void *col){
	int *k =(int *)col;
	int sum = 0;
	for(int i = 0; i < M;i++){
       sum += arr[i][*k]; 
	}
	cl_sum[*k] = sum;
	pthread_exit(NULL);
}

int main(){
	pthread_t tid[N];
	int total =0;
	int index[N];
	for(int i=0;i < M; i++){
		for(int j = 0; j<N;j++){
			printf("Enter the Number:");
			scanf("%d",&arr[i][j]);
		}
	}
	for(int i = 0; i < N; i++){
		index[i] = i;
		pthread_create(&tid[i],NULL,col_sum,&index[i]);
	}
	for(int i = 0; i < N; i++){
		pthread_join(tid[i],NULL);
		printf("col sum = %d\n",cl_sum[i]);
		total+=cl_sum[i];
	}
	printf("total=%d\n",total);
}