/**Declare a matrix of size m x n , and populate it. (Fill it) Create m threads such that each thread calculates the ith row sum.
 *Let the main thread  display each row sum result as well as the total sum.*/
#include<stdio.h>
#include<pthread.h>
#include<unistd.h>
#include<string.h>
#include<ctype.h>
#include <stdlib.h>
#define M  4
#define N  3
int arr[M][N];
int row_sum[M];
void *thread1(void *row){
	 int sum = 0;
     int *k = (int*)row;
     for(int j = 0; j < N;j++){
     	sum+=arr[*k][j];
     }
     row_sum[*k]=sum;
     free(row);
     pthread_exit(NULL);
}

int main(){
	pthread_t tid1[M];
	int i = 0;
	int total = 0;
	for(i;i < M; i++){
		for(int j = 0; j<N;j++){
			printf("Enter the Number:");
			scanf("%d",&arr[i][j]);
		}
	}
	for(i=0;i<M;i++){
		int *row = (int*)malloc(sizeof(int));
		*row = i;
		pthread_create(&tid1[i],NULL,thread1,(void*)row);
	}
	for(i = 0; i < M; i++){
		pthread_join(tid1[i],NULL);
		printf("row sum = %d\n",row_sum[i]);
		total+=row_sum[i];
	}
	printf("total=%d\n",total);
}