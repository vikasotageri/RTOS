/*Next create a common shared memory area where in one thread writes a sequence of numbers, the second thread reads the numbers, calculates their  sum and displays the result to the screen. */

#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <ctype.h>

int flag = 0;
pthread_mutex_t lock;
int arr[10];
void *thread1(void *arg){
    pthread_mutex_lock(&lock);
    for(int i = 0; i < 10; i++){
        arr[i] = i;
    }
    flag = 1;
    pthread_mutex_unlock(&lock);
}

void *thread2(void *arg){
    while(1){
    pthread_mutex_lock(&lock);
    if(flag){
       int res = 0;
       
       for(int i = 0; i < 10;i++){
          res += arr[i];
       }
       printf("sum = %d\n",res);
       pthread_mutex_unlock(&lock);
       flag = 0;
       break;
       
    }
    
    pthread_mutex_unlock(&lock);
    
   }
}
int main() {
    pthread_t tid1, tid2;

    pthread_mutex_init(&lock, NULL);

    pthread_create(&tid1, NULL, thread1, NULL);
    pthread_create(&tid2, NULL, thread2, NULL);

    pthread_join(tid1, NULL);
    pthread_join(tid2, NULL);

    pthread_mutex_destroy(&lock);

    return 0;
}

