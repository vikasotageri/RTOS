#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#define FILE_NAME  "sample.txt"
pthread_mutex_t lock;
void *count_word(void *arg){
   int count = 0;
   int in_word = 0;
   pthread_mutex_lock(&lock);
   
   FILE *fp = fopen(FILE_NAME,"r");
   if(fp == NULL){
      perror("read failed\n");
      pthread_mutex_unlock(&lock);
      exit(1);
   }
   char ch;
   while((ch = fgetc(fp)) !=EOF){
       if(isspace(ch)){
          if(in_word){
             in_word = 0;
             count++;
          }
       }
       else{
          in_word = 1;
       }
   }
   if(in_word){
       count++;
   }
   printf("Number of word %d\n",count);
   pthread_mutex_unlock(&lock);
   return NULL;
   
}

void *upper(void *arg){
   pthread_mutex_lock(&lock);
   FILE *fp = fopen(FILE_NAME,"r+");
   if(fp == NULL){
      perror("read failed\n");
      pthread_mutex_unlock(&lock);
      exit(1);
   }
   char ch;
   while((ch = fgetc(fp)) != EOF){
      if(isupper(ch)){
         fseek(fp,-1,SEEK_CUR);
         putc(tolower(ch),fp);
      }
   }
   pthread_mutex_unlock(&lock);
   printf("All uppercase letters converted to lowercase.\n");
   return NULL;
}

void *write(void *arg){
   pthread_mutex_lock(&lock);
   FILE *fp = fopen(FILE_NAME,"a+");
   if(fp == NULL){
      perror("read failed\n");
      pthread_mutex_unlock(&lock);
      exit(1);
   }
   //fseek(fp,0,SEEK_END);
   char str[] = "This file visited by there threads";
   fputs(str,fp);
   fclose(fp);
   pthread_mutex_unlock(&lock);
   return NULL;
   
}
int main(){
   pthread_t tid1, tid2,tid3;
   
   pthread_create(&tid1,NULL,count_word,NULL);
   pthread_create(&tid2,NULL,upper,NULL);
   pthread_create(&tid3,NULL,write,NULL);
   
   pthread_join(tid1,NULL);
   pthread_join(tid2,NULL);
   pthread_join(tid3,NULL);
   
   
   
}
