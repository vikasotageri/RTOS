/**Create two threads in a main program, let the first thread execute a function to display a message namely “this is thread one” , similarly let the second thread displays “this is thread two’*/
#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<pthread.h>
#include<unistd.h>

void *fun(void *msg){
  char *msg1 = (char*)msg;
  printf("%s",msg1);
}
void *fun1(void *msg2){
   char *msg = (char*)msg2;
   printf("%s",msg);
}


int main(){
   pthread_t tid1,tid2;
   char *msg = "hello from thread 1\n";
   char *msg1 = "hell0 from thread 2\n";
   if(pthread_create(&tid1,NULL,fun,(void*)msg)){
       perror("thread creation failed\n");
       return 1;
   }
   if(pthread_create(&tid2,NULL,fun1,(void*)msg1)){
       perror("thread creation failed\n");
       return 1;
   }
   pthread_join(tid1,NULL);
   pthread_join(tid2,NULL);
}
