/*Declare a matrix of size m x n , and populate it. (Fill it) Create m threads such that each thread calculates the ith row sum. Let the main thread  display each row sum result as well as the total sum.*/
#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <ctype.h>

#define M  4
#define N  3
int matrix[M][N];
int rowsum[M];

void *sum(void *arg){
    int row = *(int*)arg;
    int sum = 0;
    for(int j =0; j < N;j++){
       sum+=matrix[row][j];
    }
    rowsum[row] = sum;
    return NULL;
}

int main(){
   
   int i;
   int total = 0;
   
   for(i = 0; i < M; i++){
      for(int j = 0; j < N; j++){
          printf("Enter elements:");
          scanf("%d",&matrix[i][j]);
      }
   }
   
   pthread_t thread[M];
   int index[M];
   for(i = 0; i < M; i++){
        index[i] = i;
        pthread_create(&thread[i],NULL,sum,&index[i]);
   }
   for(i = 0; i < M; i++){
       pthread_join(thread[i],NULL);
       printf("Sum of row %d = %d\n",i,rowsum[i]);
       total +=rowsum[i];
   }
   printf("taotal sum = %d\n",total);
}
