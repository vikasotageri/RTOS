/**Create a common shared memory area where in one thread writes a string termed “Hello There”; the second thread reads the string and displays it on the screen. Also the second string converts all lower case to upper case and vice versa in the shared memory. Next the first thread will read this from the shared memory and will output the same to the screen. */

#include <stdio.h>
#include<sys/wait.h>
#include<pthread.h>
#include<unistd.h>
#include<string.h>
#include<ctype.h>
#include <stdlib.h>

int flag = 1;
char buf[100];
pthread_mutex_t lock; 

void *thread1(void *arg){
   
   pthread_mutex_lock(&lock);
   strcpy(buf,"Hello There");
   pthread_mutex_unlock(&lock);
   sleep(1); 
   pthread_mutex_lock(&lock);
      printf("%s\n",buf);
   pthread_mutex_unlock(&lock);
}
void *thread2(void *arg){
   sleep(1);
   pthread_mutex_lock(&lock); 
      printf("%s\n",buf);
      for(int i = 0; buf[i] != '\0';i++){
         if(isupper(buf[i])){
             buf[i] = tolower((unsigned char)buf[i]);
         }
         else if(islower(buf[i])){
             buf[i] = toupper((unsigned char)buf[i]);
         }
      }
   pthread_mutex_unlock(&lock); 
}

int main(){
   pthread_t tid1,tid2;
   
   int itr1,itr2;
   itr1 = pthread_create(&tid1,NULL,thread1,(void*)NULL);
   itr2 = pthread_create(&tid2,NULL,thread2,(void*)NULL);
   if(itr1 || itr2){
      perror("thread creation unsuccessfull\n");
      exit(1);
   }
   pthread_join(tid1,NULL);
   pthread_join(tid2,NULL);
   
   printf("thread 1 returned = %d\n",itr1);
   printf("thread 2 returned = %d\n",itr2);
}
