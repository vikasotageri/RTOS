#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <ctype.h>

char buf[100];           // Shared memory
int flag = 0;            // 0 = not written, 1 = written, 2 = processed
pthread_mutex_t lock;

void *thread1(void *arg) {
    // Write "Hello There"
    pthread_mutex_lock(&lock);
    strcpy(buf, "Hello There");
    printf("Thread 1 wrote: %s\n", buf);
    flag = 1;  // signal thread2
    pthread_mutex_unlock(&lock);

    // Wait until thread2 finishes processing
    while (1) {
        pthread_mutex_lock(&lock);
        if (flag == 2) {
            printf("Thread 1 reads modified string: %s\n", buf);
            pthread_mutex_unlock(&lock);
            break;
        }
        pthread_mutex_unlock(&lock);
    }
    return NULL;
}

void *thread2(void *arg) {
    // Wait until thread1 writes data
    while (1) {
        pthread_mutex_lock(&lock);
        if (flag == 1) {
            printf("Thread 2 reads: %s\n", buf);

            // Swap case
            for (int i = 0; buf[i] != '\0'; i++) {
                if (islower(buf[i]))
                    buf[i] = toupper(buf[i]);
                else if (isupper(buf[i]))
                    buf[i] = tolower(buf[i]);
            }

            printf("Thread 2 converted string: %s\n", buf);
            flag = 2;  // signal thread1
            pthread_mutex_unlock(&lock);
            break;
        }
        pthread_mutex_unlock(&lock);
    }
    return NULL;
}

int main() {
    pthread_t tid1, tid2;

    pthread_mutex_init(&lock, NULL);

    pthread_create(&tid1, NULL, thread1, NULL);
    pthread_create(&tid2, NULL, thread2, NULL);

    pthread_join(tid1, NULL);
    pthread_join(tid2, NULL);

    pthread_mutex_destroy(&lock);

    return 0;
}

