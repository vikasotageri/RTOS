/*Create two threads in a main program, let the first thread execute a function to display a message namely “this is thread one” , similarly let the second thread displays “this is thread two’.*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdint.h>
#include <sys/wait.h>
#include <unistd.h>

void *function1(void *ptr);
void *function2(void *ptr);
int main(){
	pthread_t thread1,thread2;
	char *msg1 = "this is thread one";
	char *msg2 = "this is thread two";
	int iter1,iter2;
	
	iter1 = pthread_create(&thread1,NULL,function1,(void *)msg1);
	iter2 = pthread_create(&thread2,NULL,function2,(void *)msg2);
	
	pthread_join(thread1,NULL);
	pthread_join(thread2,NULL);
	

}

void *function1(void *ptr){
   char *msg = (char *)ptr;
   printf("%s\n",msg);
}
void *function2(void *ptr){
   char *msg = (char *)ptr;
   printf("%s\n",msg);
}
