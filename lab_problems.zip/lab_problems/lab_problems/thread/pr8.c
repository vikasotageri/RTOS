/**create and save a  sample text (a file containing any text) in your current working directory . Next write a program which creates two threads such that one thread counts the total number of words present  in the file and the other thread changes all upper case characters to lower case.*/

#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#define FILE_NAME  "sample.txt"
pthread_mutex_t lock;
void *count_word(void *arg){
   int count = 0;
   int in_word = 0;
   pthread_mutex_lock(&lock);
   
   FILE *fp = fopen(FILE_NAME,"r");
   if(fp == NULL){
      perror("read failed\n");
      pthread_mutex_unlock(&lock);
      exit(1);
   }
   char ch;
   while((ch = fgetc(fp)) !=EOF){
       if(isspace(ch)){
          if(in_word){
             in_word = 0;
             count++;
          }
       }
       else{
          in_word = 1;
       }
   }
   if(in_word){
       count++;
   }
   printf("Number of word %d\n",count);
   pthread_mutex_unlock(&lock);
   return NULL;
   
}

void *upper(void *arg){
   pthread_mutex_lock(&lock);
   FILE *fp = fopen(FILE_NAME,"r+");
   if(fp == NULL){
      perror("read failed\n");
      pthread_mutex_unlock(&lock);
      exit(1);
   }
   char ch;
   while((ch = fgetc(fp)) != EOF){
      if(isupper(ch)){
         fseek(fp,-1,SEEK_CUR);
         putc(tolower(ch),fp);
      }
   }
   pthread_mutex_unlock(&lock);
   printf("All uppercase letters converted to lowercase.\n");
   return NULL;
}

int main(){
   pthread_t tid1, tid2;
   
   pthread_create(&tid1,NULL,count_word,NULL);
   pthread_create(&tid2,NULL,upper,NULL);
   
   pthread_join(tid1,NULL);
   pthread_join(tid2,NULL);
   
   
   
}
